const Promise = require('bluebird'),
			express = require('express'),
      bp      = require('body-parser'),
  		fetch		= require('node-fetch');

const payload = require('./payload');

const {Card, Suggestion} = require('dialogflow-fulfillment');
 
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

const app = express();

const docPoliciesBaseURL = 'https://docs.apigee.com/api-platform/reference/policies';


let jsonBP = bp.json({type: 'application/json'});
app.post('/', jsonBP, (req,res) =>  {

  let policy = req.body.queryResult.parameters['apigee-policy'] + '-policy';
  let foo =  { "card" :  new Card({
    title: `Title: this is a card title`,
    imageUrl: 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png',
    text: `This is the body text of a card.  You can even use line\n  breaks and emoji! 💁`,
    buttonText: 'This is a button',
    buttonUrl: 'https://assistant.google.com/'
  })};

  let responseObject = {
    //'fulfillmentText': `We found some documentation for the policy: ${policy}`,
    'fullfillmentMessages': [ foo ]

      /*
      {
        'linkOutSuggestion': {
          "destinationName": `Apigee Documentation for ${policy}`,
          "uri": `${docPoliciesBaseURL}/${policy}`
        }
      },
      {
        'text': [ `We found some documentation for the policy: ${policy}` ]
      }
    ]
      */
  };

  console.log('this is my card: %j', payload);
	res.json(payload);
});

// Start the server
const PORT = process.env.PORT || 8080;
module.exports = app.listen(PORT, () => {
	console.log(`App listening on port ${PORT}... Let's do this!`);
	console.log('Press Ctrl+C to quit.');
});

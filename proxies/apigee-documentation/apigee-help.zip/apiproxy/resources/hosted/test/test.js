process.env.NODE_ENV = 'test';

const chai  = require('chai'),
  chaiHttp  = require('chai-http'),
   server   = require('../index'),
   request  = require('./data/exampleFullfillmentRequest.json');

const should = chai.should();

chai.use(chaiHttp);

describe('Assistant Searches', () => {
  /*
  * Test the /POST route
  */
  describe('Search for "documentation for spike-arrest"', () => {
      it('it should try and find the documentation link for the spike-arrest-policy', (done) => {
        chai.request(server)
            .post('/')
            .send(request)
            .end((err, res) => {
                console.log('this is the res: %j', res);
                res.should.have.status(200);
                //res.body.should.deep.equal({ 'fulfillmentText': 'https://docs.apigee.com/api-platform/reference/policies/spike-arrest-policy'  });
              done();
            });
      });

  });
});
